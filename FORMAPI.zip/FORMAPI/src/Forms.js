import React, { useState } from 'react'
import Forms form './components'
import './App.css'
import Datepicker from '.././formapi/controls/datepicker/DatePicker'
import password from '../formapi/controls/password/Password'
import Text from '../formapi/controls/text/Text'
import TextArea from '../formapi/controls/textarea/TextArea'
import formcontrol from '../formapi/FormControl'
import fromHelper from '../formapi/FromHelper'
import useForm from '../formapi/useForm'
import RegistrationForm from '../components/RegistrationForm'


function Forms () {


  return (
    <BrowserRouter>
    <Switch>
    <Datepicker/>
       <Text/>
       <TextArea/>
       <RegistrationForm/>
       <useForm/>
       <FormControl/>
       <fromHelper/>
      





    </Switch>
    
    
    
    </BrowserRouter>
  );
  


}



export default Form