import React from 'react';
import Forms from '../components/Forms';
import './App.css';


function App() {
  return <Forms />;
}

export default App