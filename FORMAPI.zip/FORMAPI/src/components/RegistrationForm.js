import React,{useState} from "react";
import useForm from "../formapi/useForm"
import FormControl from "../formapi/FormControl";

function RegistrationForm() {

    const [formStates,setFormState]= useState ({

        fields:[
            {name:"fullName",value:""},
            {name:"dob", value:""},
            {name:"address", value:""},
            {name:"email", value:""},
            {name:"password", value:""},
    
        ]})
        const {getCurrentFormValues,eventInputValue, eventDateValue} = useForm(formStates,setFormState)
        const handleSubmit = () => {
            alert(getCurrentFormValues(formStates))
        }
        const handleClear = () => {
            eventRestForm{formStates}
        }


        return (

            <div>
                <button type="button" onClick={handleClear}> Clear Form</button><br/><br/>
                <FormControl
                control="text"
                setName="fullName"
                label="Full Name"
                formStates={formStates}
                eventInputValue={eventInputValue}
                /><br/><br/>



            </div>
        )
        }
export default RegistrationForm;