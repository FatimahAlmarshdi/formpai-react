import React from "react";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import './App.css'
import Datepicker from '.././formapi/controls/datepicker/DatePicker'
import password from '../formapi/controls/password/Password'
import Text from '../formapi/controls/text/Text'
import TextArea from '../formapi/controls/textarea/TextArea'
import formcontrol from '../formapi/FormControl'
import fromHelper from '../formapi/FromHelper'
import useForm from '../formapi/useForm'
import RegistrationForm from '../components/RegistrationForm'


function Forms () {
  return (
    <>
      <div className='form-container'>
        <span className='close-btn'>×</span>
       <Datepicker/>
       <Text/>
       <TextArea/>
       <RegistrationForm/>
       <useForm/>
       <FormControl/>
       <fromHelper/>
      </div>
    </>
  );
  }
  
  export default Forms;

