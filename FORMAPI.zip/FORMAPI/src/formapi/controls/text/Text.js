import React from "react";
import * as FormHelper from "../../FromHelper"

function Text (props) {
    const {formstates,statName,label,eventInputValue,eventInputError,...rest} = props


    const handelTextChange = stateName => e => {
        const textInput = e.target.value 
        eventInputValue(stateName,textInput)
    }

    return (
        <div>
            <label htmlFor={stateName}>{label}</label>
            <br/>
            <input type="text" id={statName} name={stateName}
            onChange={handelTextChange(stateName)}
            value={formHelper.getValue(stateName, formstates)} {...rest}/>

        </div>
    )
}
export default Text;