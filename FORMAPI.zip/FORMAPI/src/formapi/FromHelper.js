

export function restFormState(formState){
    const fields = formState.fields
    var valuesArrat =[]
    fields.map(item => {
        const newObject = {name:item.name, value:""}
        valuesArray =[...valuesArray,newObject]});
        return{
            ...formState,
            fields: valuesArray
        };
    }
export function getFormValues(formState){
    const fields= formState.fields
    var valuesObject = {}
    fields.map(
        item => valuesObject[item.name]=item.value
    );
    return JSON.stringify(valuesObject)
}
export function getValueByStateName(stateName,formState){
    const fields= formState.fields
    const stateIndex = fields.findIndex(
        item => item.name === stateName
    );
    const value = fields[stateIndex].value
   if (Array.isArray(value))
   return JSON.stringify(value)
   else
   return value
 }

 export function getValue(stateName,formState){
    const fields= formState.fields
    const stateIndex = fields.findIndex(
        item => item.name === stateName
    );
    return fields[stateIndex].value
}
export function updateValue(newValue,stateName,formState){
    const fields= formState.fields
    const stateIndex = fields.findIndex(
        item => item.name === stateName
    );
    const newObject ={name:fields[stateIndex].name, value: newValue}
    const updateFields =[
        ...formStates.fields.slice(0,stateIndex) ,
        newObject,
        ...formStates.fields.slice(stateIndex + 1) 
    ];

    
    return {
        ...formState,
        fields: updateFields
    };







