import React from "react";
import * as FormHelper from "../../FromHelper"

function formcontrol (props) {
    const {control, ...rest} = props

    switch(control){
        case 'text':
            return <Text {...rest}/>
         
        case 'password':
            return<Password {...rest}/>
        case 'TextArea':
            return <DatePicker {...rest}/>
        
        default:
            return null    
    }

    }

  export default formcontrol  