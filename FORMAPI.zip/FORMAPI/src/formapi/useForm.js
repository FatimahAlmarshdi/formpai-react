import React from "react";
import * as FormHelper from "../../FromHelper"

function useForm (formstates,setFormStates) {


    const getCurrentFormValues =() => {
        return FormHelper.getFormValues(formstates)
    }
    const getValueByStateName = (stateName) => {
        return FormHelper.getValueByStateName(stateName,formstates)
    };
    const eventInputValue = ( stateName ,newTextInput) => {
        let newFormState = FormHelper.updateValue(newTextInput, stateName, formstates)
        setFormStates(newFormState)
    };
    const eventDateValue = ( stateName ,newDate) => {
        let newFormState = FormHelper.updateValue(newDate, stateName, formstates)
        setFormStates(newFormState)
    };

    return (
        {getCurrentFormValues,getValueByStateName,eventInputValue,eventDateValue}
    );
    }
    
export default useForm
